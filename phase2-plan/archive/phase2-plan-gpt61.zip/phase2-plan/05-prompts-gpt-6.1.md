# 05 — Prompt triển khai, tiếp tục và review

Dùng với GPT-6.1 trong môi trường mở repo. Model được giữ đúng yêu cầu của người dùng; không có SDK/model API được thêm vào ứng dụng Pet-healthcare. Cấu trúc prompt gồm mục tiêu, ngữ cảnh, ràng buộc và điều kiện hoàn thành theo [hướng dẫn Codex của OpenAI](https://learn.chatgpt.com/docs/learn/best-practices).

Mỗi prompt dưới đây kế thừa nguyên tắc ở `START-HERE-PROMPT.md` nhưng **thay thế mục PHẠM VI KHỞI ĐỘNG** bằng phạm vi được nêu. Không bắt model làm lại P0/P1 đã đạt. Nếu mở chat mới, yêu cầu đọc file master để có đủ ràng buộc; không cần dán toàn bộ tài liệu vào một message khi repo đã truy cập được.

Tổ chức hiện tại: bạn làm một mình với GPT, tuần tự P0–P7 rồi đạt mốc H trong HANDOFF.md mới giao việc cho nhóm. Các prompt không giả định người khác đang xây service hay contract song song.

## 1. P2 — Notification và đường sự kiện

```text
Triển khai P2 của phase2-plan/03-delivery-plan.md trên repo này. Áp dụng nguyên tắc trong START-HERE-PROMPT.md; phạm vi P2 thay phần phạm vi khởi động. Đọc STATUS trước, xác minh P1 đã đạt bằng evidence và code, không làm lại scaffold.

Hoàn thành Notification API phân trang/unread/read/read-all/delete/send, owner/staff authorization, DB và migration riêng, idempotency, event schema, consumer inbox, retry/DLQ/replay. Port có chọn lọc contract nhánh c5736ed, bổ sung invoice/payment producer và contract phân trang hiện tại.

Thay mọi đường tạo notification của Core bằng outbox cùng transaction: appointment legacy đang còn ở Core trong giai đoạn chuyển, hotel, medical legacy, lifecycle, invoice, payment, public rescue và reminder. Khi P3 chuyển Clinic, producer tương ứng phải chuyển quyền sở hữu chứ không để cả hai cùng phát.

Không chờ broker trên đường commit nghiệp vụ, không ACK trước commit consumer, không ACK message gốc trước khi retry/DLQ republish được confirm. Request gửi thủ công chỉ trả thành công sau lưu Notification DB. Rà soát message gửi cho UI để không tuyên bố đã nhận khi mới enqueue.

Chạy T05/T09-T15/T32 và tests liên quan; chứng minh broker/consumer dừng rồi phục hồi không mất/trùng dữ liệu. Cập nhật STATUS/evidence và báo rõ phần chưa chạy. Thực hiện code tới khi P2 đạt, không chỉ đưa hướng dẫn.
```

## 2. P3 — Clinic & Scheduling

```text
Triển khai P3 theo phase2-plan/03-delivery-plan.md. Kế thừa ràng buộc master, thay scope khởi động bằng P3. Đọc STATUS và hợp đồng file 02 trước.

Chuyển toàn bộ Appointment gồm Spa, MedicalRecord, MedicalImage và history kind=appointment sang Clinic với schema/migration/client riêng. Port cả GET trong backend/src/routes/lists.ts, calendar và write/lifecycle routers; không để read vẫn truy vấn bảng Core.

Giữ unique slot pet/ngày/giờ, optimistic revision và transaction bệnh án+hoàn thành lịch+outbox. Thêm durable idempotency. Core directory API/events và Clinic projection phục vụ search/count/related trước pagination; phân quyền từ nguồn có thẩm quyền, không từ projection cũ. Không copy credentials vào projection.

Giữ JSON/date/VND/redaction/role behavior hiện tại. Tạo tests PostgreSQL hai replica tranh slot, rollback bệnh án, idempotency retry, query pagination/scope và projection version/lag. Chưa đổi traffic đang sử dụng hoặc xóa bảng legacy. Ghi rõ ranh giới billing cần P4 nếu mới dùng interface chưa hoàn tất.

Hoàn thành P3, chạy T05-T09/T22-T24/T31 phù hợp, cập nhật STATUS/evidence, không đánh toàn bộ phase2 hoàn tất.
```

## 3. P4 — Hóa đơn và race condition liên dịch vụ

```text
Triển khai P4, ưu tiên correctness theo phase2-plan/02-contracts-and-consistency.md mục 8. Áp dụng master; scope hiện tại là P4. Đọc code/evidence proof of concept P1 và Clinic P3 trước khi chỉnh.

Core sở hữu BillingOperation PREPARING/COMMITTED/ABORTED, invoice unique theo source, operation status API và reconciler. Clinic sở hữu reservation HELD/INVOICED/RELEASED dưới cùng row lock với lifecycle. Không dùng GET status rồi insert invoice thay reservation.

Commit và abort Core khóa cùng operation; late commit sau ABORTED phải thất bại. Không tự release reservation vì TTL/timeout. Finalize/release idempotent qua event và đối soát endpoint read-only không gọi vòng. Thêm lease cho reconciler và audit an toàn.

Giữ giá/owner checkout Spa/hotel settlement như baseline. Frontend xử lý 202 pending/unknown đúng, retry cùng key và tra operation; success trả invoice cũ nếu đã commit. mode=unbilled lọc reservation trước pagination. Backfill thiết kế cho invoice lịch sử, không phát lại thu tiền.

Chạy crash matrix và T16-T21/T27/T33 trên DB thật với concurrency barrier. Kiểm tra loss of response, commit-vs-abort, undo-vs-prepare, delayed prepare và finalize/release sai thứ tự. Không sửa trạng thái DB bằng tay để test qua. Báo PASS/FAIL/SKIP trung thực, cập nhật STATUS/evidence.
```

## 4. P5 — Frontend và bootstrap

```text
Hoàn thành P5 theo phase2-plan/03-delivery-plan.md, giữ ràng buộc master. Scope lần này là session/query/bootstrap/frontend tích hợp ba service; không đổi giao diện lớn.

Đối chiếu commit refactor 139e4dd với main hiện tại và port phần phù hợp, giữ sửa lịch riêng của main. Tách SessionContext, query trang, dashboard vùng Core/Clinic, unread Notification. Bỏ polling bootstrap toàn cục; polling có visible/online/jitter/backoff, invalidation đúng vùng.

Giữ phân trang/filter/search, option selector, timezone và stale response protection. Khi ghi đã lưu nhưng refresh thất bại phải báo đã lưu, cho tải lại và không tạo operation mới. Invoice pending theo P4; Notification lỗi không logout, không đổi unread thành 0 giả. Kiểm /auth/me lỗi tạm thời khác 401 hợp lệ.

Chạy T22/T25-T27/T31 và E2E appointment/Spa/hotel/billing/medical/activation/rescue trên stack thử riêng. Thu network evidence trước/sau theo cùng hành trình. Giữ bootstrap adapter chỉ khi còn caller, ghi rõ nơi cần; không xóa API trước khi client đã chuyển. Cập nhật STATUS/evidence.
```

## 5. P6 — Auth surge, scale và quan sát

```text
Triển khai P6 theo bộ phase2-plan, thay scope khởi động trong master bằng P6. Không tự tách Identity service.

Tách limiter login/register/activation khỏi /auth/me, dùng counter chung Redis khi nhiều replica; giữ mô hình nhiều khách chung Wi-Fi. Thêm giới hạn concurrency/pending queue cho hash async, timeout/admission rõ ràng. Không giảm PBKDF2 iterations, không nhận password yếu để đạt benchmark. Test Redis lỗi theo policy thiết kế.

Hoàn thiện JWT key separation, algorithm/issuer/audience, credential service và khóa endpoint nội bộ. Không cấp khóa ký user cho Clinic/Notification. Viết migration token/session cho cutover demo và ghi giới hạn revocation; không tự thêm refresh-token product feature.

Hoàn thiện liveness/readiness/degraded, graceful shutdown, request timeouts, logs/metrics/correlation và pool budget. Chạy nhiều Clinic replica qua proxy và chứng minh request thực đến nhiều instance; request dedup/unique vẫn đúng xuyên replica. Không dùng memory state làm invariant.

Chạy T01-T04/T11/T28/T29/T34 và E2E auth/activation liên quan. Báo endpoint/môi trường thử và actual test results, cập nhật STATUS. Không triển khai ra môi trường đang dùng.
```

## 6. P7 — Migration và rehearsal

```text
Thực hiện P7 theo phase2-plan/04-validation-and-cutover.md, trên bản copy/fixture DB thử được xác minh. Áp dụng master; không cutover DB người dùng đang sử dụng.

Tạo manifest-driven migration dry-run/export/import/validate. Giữ ID/timestamp/revision/status đọc, tiền và history; split history theo kind; backfill invoice snapshot và INVOICED reservation; seed directory projection có version. Có kiểm tra orphan/duplicate/unknown schema và report trước ghi.

Backup rồi thử restore DB riêng. Diễn tập ngừng ghi thực ở gateway+workers, import/đối chiếu, chuyển gateway code trong lúc khóa ghi, mở ghi thử và kiểm tra hành trình. Không dual-write không kiểm soát, không seed reset demo và không xóa bảng cũ trong cùng rollout.

Chứng minh rollback trước ghi mới. Sau ghi mới, không chỉ trỏ lại DB cũ; phải có reverse migration được test hoặc forward-fix. Ghi giới hạn rollback cụ thể. Chạy T30 cùng hồi quy I01-I12, xác nhận service credentials không truy cập DB chéo.

Giao runbook reviewable, scripts, report và STATUS cập nhật. Nếu kết quả không khớp, giữ môi trường thử để chẩn đoán, không sửa dữ liệu lịch sử âm thầm.
```

## 7. P8 — Benchmark và báo cáo bảo vệ

```text
Thực hiện P8 sau khi P7 và các blocker correctness đã đạt. Áp dụng master; scope là benchmark trên dữ liệu thử và bàn giao, không thêm service/framework.

Theo file 04, so B0/B1/B2 cùng tổng tài nguyên và B3 tăng tài nguyên Clinic công khai. Cùng fixture/contract/workload version, warmup và repeats. Workload có đăng ký→tạo pet→đặt khám, login→tra cứu, phiên cũ không login lại; thêm clinic-heavy/read-heavy/auth-heavy/common-IP và tải hotel nền.

Đo end-to-end completion, p95/p99, lỗi, policy 429, overload 503, CPU/RAM/DB/pool/lock, hash duration, outbox/queue/notification lag. Không tính 202 invoice accepted là đã hoàn thành nghiệp vụ; không tắt bảo vệ hoặc giảm password work factor. Nếu máy không đủ run dài, ghi screening và giới hạn.

Lưu manifest/raw data/commands và viết report trung thực. Chạy demo broker/consumer/replica down với khôi phục, clean setup và E2E cuối phù hợp. Hoàn thiện sơ đồ, ADR, API/event docs, runbook và STATUS; không tự suy ra số người dùng tối đa/điểm số. Báo rõ phần đạt/chưa đạt và rủi ro còn lại.
```

## 8. Prompt tiếp tục khi đổi chat

```text
Tiếp tục triển khai pha 2 Pet-healthcare, không khởi động lại từ đầu.
Đọc phase2-plan/STATUS.md, README.md, START-HERE-PROMPT.md và thiết kế liên quan chặng hiện tại. Phạm vi lần này là chặng tiếp theo đủ điều kiện trong STATUS; phần PHẠM VI KHỞI ĐỘNG của master không áp dụng lại nếu P0/P1 đã đạt.
Kiểm tra git status/diff và evidence để xác minh tiến độ. Giữ nguyên code/local changes người dùng, không reset/stash/checkout đè. Phân biệt lỗi mới với lỗi baseline. Làm tiếp đầu việc chưa xong, sửa và test tới khi chặng đạt; không dừng ở kế hoạch hoặc dựng scaffold. Cập nhật STATUS/evidence cùng bước tiếp theo trước khi kết thúc. Nếu bị chặn, ghi đúng điều kiện còn thiếu và tiếp tục phần độc lập có thể làm.
```

## 9. Prompt review độc lập

```text
Review chỉ đọc implementation pha 2 so với phase2-plan/01-architecture.md, 02-contracts-and-consistency.md và 04-validation-and-cutover.md. Kiểm tra code/diff thực, không tin nhãn DONE hoặc lời tóm tắt của agent trước.
Tìm lỗi theo tác động: quyền dữ liệu, loss/duplicate event, invoice-vs-undo race, late commit sau abort, ownership/DB access chéo, idempotency nhiều replica, pagination/related, migration/rollback, auth common-IP và frontend timeout.
Mỗi finding nêu file:dòng, điều kiện tái hiện, invariant bị phá và hướng sửa nhỏ nhất. Tách lỗi đã chứng minh, rủi ro cần test và nhận xét tùy chọn. Không sửa file hoặc chạy suite ghi vào DB đang dùng. Nếu cần kiểm chứng động, dùng môi trường thử đã xác minh. Cuối cùng kết luận chặng nào đủ/không đủ điều kiện tiếp tục và test nào thực sự đã chạy.
```

## 10. Prompt sửa sau review

```text
Sửa các finding đã được xác nhận trong review pha 2, ưu tiên correctness/security/data loss. Đọc STATUS và thiết kế; giữ phạm vi thay đổi nhỏ và code người dùng. Tái hiện bằng test có giá trị, sửa nguyên nhân rồi chạy lại đúng nhóm tests và integration liên quan. Không bỏ assertion/hạ kỳ vọng hoặc đổi API âm thầm để PASS. Cập nhật evidence, contract/ADR nếu thật sự cần thay thiết kế và ghi rõ finding đã giải quyết/còn lại. Tiếp tục tới khi các lỗi trong phạm vi đã sửa và kiểm chứng, không chỉ đưa lời khuyên.
```

## 11. Prompt chạy liên tục toàn bộ (tùy chọn)

```text
Tôi giao triển khai liên tục P0-P8 của bộ phase2-plan trong repo này, trên code và dữ liệu thử cục bộ. Áp dụng toàn bộ nguyên tắc START-HERE-PROMPT.md, nhưng thay phạm vi P0/P1 ở cuối master bằng toàn bộ P0-P8. Đọc STATUS để tiếp tục từ bước chưa đạt.
Tự làm các bước được phép, sửa lỗi và kiểm thử qua từng gate. Không chờ xác nhận giữa các tác vụ code/test thông thường; không bỏ gate khi khó. Không commit/push/merge hoặc cutover dữ liệu đang sử dụng, không thêm service thứ tư, không tự tạo sub-agent. Khi hết context, ghi checkpoint rõ trong STATUS; lượt sau tiếp tục, không đánh hoàn tất giả. Nếu có blocker môi trường, ghi nguyên nhân và hoàn thành phần độc lập còn làm được.
```

## 12. Prompt theo vai trò sau bàn giao H

Chỉ sau H, thành viên nhận việc dùng tiền tố dưới đây trước task P8 hoặc sửa lỗi cụ thể:

```text
Tôi nhận vai trò [Clinic / Core-tích hợp / Notification-frontend] sau mốc H theo file 03. Đọc HANDOFF.md, STATUS.md và evidence/handoff-report.md, xác minh đã bàn giao và tái hiện hướng dẫn chạy trên môi trường thử riêng trước khi sửa. Nếu H chưa đạt, báo rõ công việc tách còn thiếu, không giả định service hoàn chỉnh.
Làm trong branch/worktree hiện tại của tôi, giới hạn file theo phần phụ trách. Không sửa file chung package-lock/Compose/gateway khi chưa đồng bộ với người tích hợp; chuẩn bị patch hoặc ghi yêu cầu cụ thể. Đọc contract chung, không tạo bản contract khác. Tự viết tests phần mình và cung cấp evidence để người tích hợp chạy end-to-end. Không spawn agent; đây là phân công giữa các thành viên nhóm sau bàn giao.
```

Thay phần trong ngoặc vuông bằng vai trò thật. Không chạy cả ba prompt trên cùng working tree với quyền sửa các file trùng nhau.

## 13. Prompt chuẩn bị bàn giao sau khi tách

```text
Tôi đang tự tách service và chỉ bàn giao cho nhóm sau khi hoàn thành nền tảng. Hãy kiểm tra mốc H theo phase2-plan/HANDOFF.md bằng code và test evidence thực tế, không dựa vào nhãn DONE. Áp dụng ràng buộc master.
Nếu P0-P7 còn phần được giao chưa hoàn thành, tiếp tục sửa và kiểm thử trong môi trường thử riêng tới khi đạt; không chuyển chúng thành việc của thành viên khác. Nếu bị chặn thật sự, ghi rõ blocker và các tiêu chí H chưa đạt.
Khi đủ điều kiện, tạo evidence/handoff-report.md với mốc code, lệnh chạy thực, contracts, dữ liệu thử, test results, known issues và task nhận bàn giao riêng cho Clinic/Notification-UI. Tự kiểm hướng dẫn clean setup; việc hai thành viên chạy lại trên máy họ phải được ghi là chờ xác nhận nếu chưa có bằng chứng. Không commit/push hoặc thay DB đang dùng. Cập nhật STATUS phân biệt nền tảng sẵn sàng với việc thành viên đã tiếp nhận.
```
