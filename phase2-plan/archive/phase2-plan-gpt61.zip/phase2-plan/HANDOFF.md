# Mốc H — Tách xong để bàn giao cho nhóm

Người thực hiện trước H: bạn và GPT-6.1 trong một luồng triển khai tuần tự. Người nhận sau H: hai thành viên còn lại. H không là trạng thái đã đạt; mọi mục dưới đây hiện là tiêu chí chờ kiểm chứng.

## 1. “Tách xong” nghĩa là gì?

Ba service đã có ownership thực và chạy được hành trình nghiệp vụ; không chỉ chuyển file vào ba thư mục. P0–P7 phải đạt, bao gồm auth/internal security và rehearsal dữ liệu thử. P8 benchmark đầy đủ và tài liệu bảo vệ có thể làm cùng nhóm sau H.

- [ ] Core, Clinic và Notification build/start độc lập; DB role không truy cập chéo; gateway route read/write đúng.
- [ ] Khách mới đăng ký → tạo pet → đặt khám → ghi bệnh án → invoice → notification chạy được trên UI.
- [ ] Spa/hotel/activation và dữ liệu phân trang hiện có không bị mất chức năng.
- [ ] Không có hai appointment trùng slot; bệnh án/completion atomic; invoice-vs-undo và late commit-vs-abort có test thật.
- [ ] Notification/broker dừng rồi phục hồi không mất/trùng event; inbox/outbox/retry/DLQ hoạt động.
- [ ] Owner/staff scopes, JWT/internal credentials, limiter chung và auth surge guards có test.
- [ ] Bootstrap không tải lại toàn hệ thống định kỳ; UI phân biệt pending/saved/refresh failed.
- [ ] Migration trên dữ liệu thử giữ IDs/history/payment totals; restore và giới hạn rollback được kiểm chứng.
- [ ] Ít nhất hai Clinic replica đã được kiểm tra định tuyến và correctness; số đo capacity đầy đủ để P8 thực hiện sau.
- [ ] API/event/schema đã chốt phiên bản; không còn stub trả thành công giả hoặc TODO trên đường chạy chính.
- [ ] Known issues có mức độ và owner; không còn blocker mất dữ liệu, sai quyền hoặc sai tiền. Phần chưa benchmark không được gọi là đã chịu tải tốt.

Không chờ báo cáo trình bày đẹp hoặc tính năng mở rộng trước khi bàn giao; vẫn phải đạt correctness và khả năng chạy lại độc lập.

## 2. Gói bàn giao tối thiểu

| Thành phần | Nội dung phải có |
| --- | --- |
| Mốc code | Branch/HEAD, mô tả dirty changes nếu có, danh sách migration và contract version; không tự commit/push nếu chưa được giao |
| Chạy local | Prerequisite, env.example không secret, build/start/health/smoke commands đã chạy thật, ports/project name |
| Dữ liệu | Fixture tổng hợp cho DB mới riêng; backup/restore/migration report; cấm seed vào DB đang dùng |
| Contracts | Public/internal OpenAPI, event schema, ownership và phiên bản tương thích |
| Kiểm chứng | Test commands, PASS/FAIL/SKIP, evidence crash/race, giới hạn scale chưa đo |
| Vận hành | Cách xem log theo correlationId, DLQ/replay, operation pending/reconcile, restart service |
| Backlog sau H | Task cụ thể theo thành viên, acceptance criteria, file sở hữu và dependency |

Ghi gói thực tế vào `phase2-plan/evidence/handoff-report.md` khi đạt H; không tạo report PASS sẵn. Dùng `STATUS.md` làm điểm bắt đầu cho người nhận.

## 3. Buổi tiếp nhận

1. Bạn chạy demo hành trình và giải thích ranh giới dữ liệu/transaction cùng một ca lỗi.
2. Mỗi người nhận chạy bản code bàn giao trên môi trường thử riêng theo hướng dẫn; không dùng DB đang hoạt động của bạn.
3. Thành viên Clinic chạy test slot và invoice/undo; thành viên Notification/UI chạy replay và một E2E. Người nhận phải tái hiện được bằng hướng dẫn, không chỉ xem video.
4. Người nhận trình bày lại service sở hữu gì, gọi API nào, phát/nhận event nào và khi dependency lỗi thì hệ thống phản hồi ra sao.
5. Chốt task đầu tiên nhỏ, có test và một PR review trước khi mở rộng quyền sửa. Nếu chưa chạy được thì sửa runbook/môi trường, không coi bàn giao hoàn tất.

## 4. Quy tắc sau bàn giao

Bạn giữ Core và tích hợp chung. Thành viên Clinic phụ trách test/sửa lỗi/đo scale miền khám; thành viên Notification/UI phụ trách thông báo/E2E/demo. Mỗi người chịu trách nhiệm tests phần mình; benchmark và báo cáo ghép bằng cùng run manifest.

Không tự đổi API/event/schema xuyên service, xóa migration hoặc sửa shared lockfile/Compose ngoài người tích hợp. Không đẩy việc tách service chưa hoàn thành thành “task bảo trì” cho người nhận mà không ghi rõ tình trạng. Nếu bạn muốn giao sớm hơn H, đó là thay đổi cách tổ chức và phải được xác nhận trong STATUS, không là giả định của GPT.
