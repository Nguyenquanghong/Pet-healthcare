# Pha 2 — Bộ thiết kế và giao việc cho GPT-6.1

Ngày lập/cập nhật: 11/10/2026. Phiên bản kế hoạch: 1.1 — một người tách service trước, bàn giao nhóm sau. Trạng thái: **thiết kế để triển khai; chưa có microservices mới được code hoặc kiểm thử bởi bộ tài liệu này**.

## Quyết định và phạm vi

Trong một tháng, **bạn tự tách service trước với GPT-6.1, rồi mới giao việc cho hai thành viên còn lại**. Không tính ba người cùng code ngay từ đầu. Đích là ba service nghiệp vụ: **Core**, **Clinic & Scheduling**, **Notification**. Giữ React/TypeScript/Express/Prisma/PostgreSQL; bổ sung RabbitMQ cho sự kiện, Redis cho giới hạn request dùng chung. Không chuyển Spring Boot, thêm Reporting hoặc triển khai Kubernetes trong phạm vi chính.

Clinic sở hữu cả lịch khám và lịch Spa để giữ cơ chế chống trùng pet/ngày/giờ đang có. Core giữ tài khoản, hồ sơ chủ nuôi/thú cưng, hotel và tài chính. Identity & Customer là phương án mở rộng có điều kiện sau đo tải, chưa phải service thứ tư được giao triển khai.

Mục tiêu cần chứng minh: triển khai/scale Clinic riêng; thông báo dừng không làm mất giao dịch khám; dữ liệu và quyền truy cập tách rõ; tải đăng ký/tra cứu tăng không gây lỗi dây chuyền ngoài mức đã đo. Không cam kết điểm số hoặc năng lực phục vụ trước khi có số liệu.

## Đọc theo thứ tự

| Tài liệu | Dùng để làm gì |
| --- | --- |
| [01-architecture.md](01-architecture.md) | Ranh giới service, quyền sở hữu dữ liệu, sơ đồ, ADR và cấu trúc repo |
| [02-contracts-and-consistency.md](02-contracts-and-consistency.md) | API, event, outbox/inbox, transaction, giao thức hóa đơn và phân quyền |
| [03-delivery-plan.md](03-delivery-plan.md) | Lộ trình một người làm P0–P7, mốc H bàn giao, P8 hoàn thiện cùng nhóm |
| [HANDOFF.md](HANDOFF.md) | Điều kiện tách xong, gói bàn giao và buổi tiếp nhận trên máy thành viên |
| [04-validation-and-cutover.md](04-validation-and-cutover.md) | Ma trận test, benchmark, migration/cutover/rollback và demo bảo vệ |
| [05-prompts-gpt-6.1.md](05-prompts-gpt-6.1.md) | Prompt từng chặng, tiếp tục công việc, review và xử lý thất bại |
| [START-HERE-PROMPT.md](START-HERE-PROMPT.md) | Prompt khởi động hoàn chỉnh để sao chép vào GPT-6.1 trong repo |
| [STATUS.md](STATUS.md) | Bảng tiến độ và bàn giao phiên; ban đầu tất cả implementation đều TODO |
| [SOURCES.md](SOURCES.md) | Bằng chứng từ Git và các nguồn kỹ thuật chính thức |

Đường dẫn trong thiết kế là **đề xuất** trừ khi được ghi là file hiện có. Lệnh mang nhãn `TO IMPLEMENT` chưa được tạo và chưa được chạy. Các mục tiêu benchmark là tiêu chí dự kiến, không phải kết quả đo.

## Cách giao việc cho GPT-6.1

1. Mở repo này trong môi trường coding có quyền đọc/sửa file và chạy kiểm thử; chọn GPT-6.1 nếu có trong tài khoản/client.
2. Dán nội dung [START-HERE-PROMPT.md](START-HERE-PROMPT.md). Prompt giao P0 và P1: khảo sát baseline, dựng nền tảng và thử sớm giao thức rủi ro cao; không tự cutover dữ liệu đang dùng.
3. Sau mỗi chặng, xem diff, kết quả test và cập nhật `STATUS.md`. Tự triển khai tiếp bằng prompt P2–P7 theo thứ tự; chỉ giao cho thành viên khác khi đạt H. Sau đó làm P8 theo vai trò bàn giao.
4. Khi đổi chat, dùng prompt tiếp tục; GPT phải đọc trạng thái thực và không làm lại việc đã đạt.
5. Có thể giao chế độ chạy liên tục P0–P8 bằng prompt riêng, nhưng các điều kiện nghiệm thu và bảo toàn dữ liệu vẫn áp dụng.

Không cần gửi toàn bộ code qua chat khi model đã mở repo. Nếu model chỉ có chat thông thường, đính kèm bộ tài liệu và source; model phải nói rõ giới hạn thực thi, không giả vờ đã chạy test.

## Quy tắc sử dụng bộ tài liệu

- Các file 01–04 là thiết kế thống nhất hiện tại. Tài liệu khảo sát cũ `docs/phase2-architecture-proposal.md` là bối cảnh; không phải phụ thuộc bắt buộc khi chuyển repo sang máy khác.
- Thay đổi thiết kế phải ghi quyết định, tác động và test cần sửa; không âm thầm đổi contract để cho test qua.
- Code thực tế ở lần bắt đầu có thể khác SHA khảo sát. P0 phải xác minh lại bằng `git status`, lịch sử và test.
- Không chép nguyên nhánh Java hoặc nhánh Notification cũ đè lên main.
- Tài liệu này không yêu cầu tạo sub-agent. Mặc định một coding agent làm theo thứ tự; chỉ dùng thêm agent khi người dùng cho phép riêng.
- Không commit/push/merge tự động. Có thể chuẩn bị diff và đề xuất commit theo từng chặng.

Thư mục `phase2-plan/` được đặt ở root vì `docs/` hiện bị loại khỏi Git bởi `.git/info/exclude` trên máy khảo sát. Bộ mới không dựa vào file bị ignore; chưa được stage/commit.
