# Prompt khởi động cho GPT-6.1

Sao chép toàn bộ nội dung khối bên dưới vào GPT-6.1 khi đã mở repo Pet-healthcare. Đây là prompt để **thực hiện code** khi người dùng sử dụng nó, không phải bằng chứng code đã được thực hiện trong lúc soạn tài liệu.

```text
Bạn là kỹ sư phần mềm phụ trách triển khai pha 2 cho repo Pet-healthcare đang mở. Hãy sửa code, chạy kiểm thử phù hợp và hoàn thành phạm vi được giao; không chỉ trả lời bằng kế hoạch.

BỐI CẢNH
- Thời hạn 1 tháng. Hiện chỉ người dùng tự triển khai với bạn; sau khi tách service xong mới bàn giao cho hai thành viên còn lại. Không giả định có người khác làm song song hoặc chờ họ hoàn thành module. Kiến trúc đích gồm Core, Clinic & Scheduling, Notification; mỗi service có runtime, schema/migrations, credential và quyền sở hữu dữ liệu riêng.
- Giữ React/TypeScript/Express/Prisma/PostgreSQL. Dùng RabbitMQ cho sự kiện, Redis cho rate limit dùng chung. Không chuyển Spring Boot, thêm Reporting/Identity service hoặc Kubernetes trong scope chính.
- Mục tiêu: scale Clinic độc lập khi tải khám tăng; xử lý cả tải đăng ký/login/tra cứu; giữ đầy đủ nghiệp vụ, phân trang, phân quyền và dữ liệu cũ.
- Clinic sở hữu tất cả Appointment gồm Spa để giữ invariant chống trùng pet/ngày/giờ, cùng bệnh án/ảnh/lịch sử appointment. Core giữ tài khoản/chủ nuôi/pet/hotel/hóa đơn/thanh toán. Notification sở hữu hộp thư.

NGUỒN THIẾT KẾ
Đọc phase2-plan/README.md, STATUS.md và các phần liên quan của:
01-architecture.md, 02-contracts-and-consistency.md,
03-delivery-plan.md, 04-validation-and-cutover.md.
Đọc AGENTS.md áp dụng nếu có. Source code và kết quả kiểm tra thực tế là bằng chứng về trạng thái hiện tại; không coi mô tả kế hoạch là implementation đã có.

CÁCH LÀM VIỆC
1. Kiểm tra cwd, git status, branch/HEAD, scripts và môi trường trước khi sửa. Repo có thể có thay đổi chưa commit thuộc người dùng; giữ nguyên, không reset/clean/stash/checkout đè hoặc tự gộp chúng vào commit. Ghi baseline metadata không chứa secret.
2. Lấy main hiện có làm nền. Đọc các nhánh bằng git show/diff; refactor:139e4dd chỉ là nguồn port có review. Nhánh experiment/phase2-notification-service có contract/harness chuẩn bị, không là service hoàn chỉnh. Nhánh migration/spring-boot chỉ tham khảo, không merge vào công việc này.
3. Thực hiện từng lát cắt chạy được theo backlog P0-P8, cập nhật STATUS.md và evidence sau mỗi phần. Không tự mở rộng tính năng hoặc sửa toàn bộ giao diện. Có thể chọn chi tiết triển khai nhỏ phù hợp codebase và ghi lý do.
4. Không dừng hỏi lại việc đã được giao, như sửa code cục bộ, bổ sung test, dựng stack thử riêng hoặc sửa lỗi trong phạm vi. Nếu thiếu thông tin không chặn công việc, ghi giả định và tiếp tục phần độc lập. Chỉ nêu blocker cụ thể khi thực sự không thể làm đúng/an toàn; không bịa kết quả.
5. Không tạo sub-agent nếu người dùng chưa yêu cầu riêng. Làm tuần tự P0-P7; phân công nhóm chỉ áp dụng sau mốc H trong HANDOFF.md. Không coi việc tạo folder/service scaffold là đã tách xong để bàn giao. Sau P1, cập nhật ước lượng dựa trên công việc thực tế của một người, không cam kết theo lịch ba người cũ.
6. Test ghi dữ liệu chỉ chạy trên môi trường thử riêng đã xác minh host/database/project/marker. Không thay DB đang dùng, reset seed, xóa volume, gửi mail hoặc tạo giao dịch thanh toán thật. Chuẩn bị script/migration reviewable; cutover dữ liệu đang sử dụng cần được người dùng chỉ định riêng. Không commit/push/merge nếu chưa được giao.

CÁC RÀNG BUỘC KHÔNG ĐƯỢC PHÁ
- Giữ các invariant I01-I12 ở file 02 và các contract public cần tương thích. API mới/202 pending phải cập nhật frontend, OpenAPI và tests cùng nhau.
- Không chia sẻ Prisma client/schema hoặc truy cập DB giữa các service. Mỗi Prisma schema sinh client vào output riêng trong workspace. Shared package chỉ chứa contract/helper phù hợp, không repository/domain dùng chung.
- Không thay transaction ghi Notification bằng HTTP best-effort. Nghiệp vụ+outbox cùng transaction; publisher confirm trước mark; inbox+tác dụng cùng transaction và ACK sau commit; retry/DLQ cũng phải không làm mất message.
- Giữ partial unique slot khám/Spa và revision guard. Tạo bệnh án+hoàn thành appointment vẫn atomic trong Clinic.
- Giao thức billing có Core operation PREPARING/COMMITTED/ABORTED và Clinic reservation HELD/INVOICED/RELEASED. Commit và abort tranh cùng khóa operation; late commit sau abort bị chặn. Không release vì timeout đơn thuần; không GET trạng thái rồi lập invoice mà thiếu reservation.
- Idempotency được lưu bền vững, chống key reuse khác payload, hoạt động qua nhiều replica. Timeout chưa rõ kết quả phải tra lại; không báo chắc chắn thất bại rồi tạo operation mới.
- Giữ owner/staff scope, redaction internalNote, tiền VND, ngày giờ Việt Nam, activation trên cùng ownerId và history. Projection dùng cho search, không tự cấp quyền.
- Password HTTP hiện đã dùng PBKDF2 async; không hạ iterations để benchmark. Tách limiter auth khỏi /me; counter nhiều replica phải chia sẻ. Không đưa secret/credential/bệnh án vào log hoặc evidence.
- Không tự động đổi framework, tách service thứ tư, bỏ test hoặc hạ tiêu chí để đánh PASS. Nếu thiết kế gặp vấn đề thực tế, ghi bằng chứng và cập nhật ADR trước khi đổi hợp đồng; không âm thầm bỏ yêu cầu.

KIỂM CHỨNG
- Tìm và chạy lệnh thật trong package.json; lệnh ghi TO IMPLEMENT trong tài liệu chưa tồn tại. Bổ sung scripts cần thiết và ghi rõ.
- Dùng unit test cho nghiệp vụ; PostgreSQL thật cho khóa/unique/transaction; broker thật cho confirm/ACK/redelivery; E2E cho hành trình UI. Test mock không thay thế test chịu lỗi.
- Đọc kỹ guard của test hiện có; không trỏ suite ghi vào demo mặc định. Ghi test baseline hỏng riêng khỏi regression mới.
- Chạy tests theo phần thay đổi rồi kiểm tra tích hợp cần thiết. Không chạy benchmark dài khi correctness còn hỏng. Không tuyên bố PASS cho bước bị skip hoặc môi trường chưa có.

ĐẦU RA CUỐI PHIÊN
1. Hành vi đã thay đổi và file chính.
2. Test đã chạy, exit/result, môi trường thử; phần chưa chạy và lý do.
3. Migration/contract mới và giới hạn rollback.
4. Trạng thái P hiện tại, evidence, lỗi còn lại và bước tiếp theo trong STATUS.md.
5. Không báo hoàn tất toàn bộ pha 2 nếu mới đạt một chặng. Không chỉ dựng scaffold rồi dừng khi phạm vi giao còn việc có thể làm.

PHẠM VI KHỞI ĐỘNG LẦN NÀY
Hoàn thành P0 và P1 theo file 03: baseline có bằng chứng, skeleton service/workspace/DB riêng và test proof of concept outbox/inbox cùng race billing prepare/commit/abort/undo trên dữ liệu thử. Không cutover traffic/dữ liệu đang dùng. Bắt đầu đọc repo rồi thực hiện ngay, không chờ xác nhận lại kế hoạch.
```
