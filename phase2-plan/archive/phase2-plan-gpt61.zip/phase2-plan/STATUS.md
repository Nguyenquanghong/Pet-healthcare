# Trạng thái triển khai pha 2

Cập nhật kế hoạch: 11/10/2026, phiên bản 1.1. Hiện một người tự triển khai với GPT; hai thành viên khác chỉ nhận việc sau mốc H. **Chỉ bộ kế hoạch/prompt được soạn; chưa triển khai code theo kế hoạch này.**

## Chặng

| ID | Trạng thái | Điều kiện tiếp tục | Evidence |
| --- | --- | --- | --- |
| P0 | TODO | Đọc repo/working tree và xác minh môi trường thử | Chưa có baseline run mới |
| P1 | TODO | P0 đạt | Chưa có scaffold/proof of concept |
| P2 | TODO | P1 đạt | Chưa triển khai |
| P3 | TODO | P1 đạt | Chưa triển khai |
| P4 | TODO | P3 đạt, P1 billing proof đạt | Chưa triển khai |
| P5 | TODO | P2/P4 đủ contract | Chưa triển khai |
| P6 | TODO | P1 đạt; phối hợp P2/P3 | Chưa triển khai |
| P7 | TODO | P5/P6 và correctness đạt | Chưa rehearsal |
| H | TODO | P0–P7 đạt và checklist HANDOFF.md có evidence | Chưa bàn giao cho thành viên khác |
| P8 | TODO | P7 đạt | Chưa benchmark |

Trạng thái cho phép: TODO / IN_PROGRESS / BLOCKED / DONE. DONE chỉ khi điều kiện nghiệm thu và bằng chứng của chặng đạt; không suy ra từ việc tạo file hoặc kết quả test cũ trên nhánh khác.

## Điểm bắt đầu

- Repo khảo sát: `C:\Users\Admin\Documents\KTPM\Pet-healthcare`.
- Branch/HEAD lúc khảo sát: `main`, `add596e`.
- Những thay đổi cục bộ quan sát trước khi soạn bộ mới: Dockerfile.frontend, README.md, backend/README.md, backend/src/app.ts, benchmarks/kaggle/notebook.ipynb, docker-compose.yml, frontend/README.md, frontend/nginx/default.conf.template; test http-proxy và các file benchmark PCN chưa tracked. Danh sách này là ảnh chụp lịch sử, P0 phải kiểm tra lại.
- `docs/` đang bị ignore cục bộ; bộ chính nằm tại `phase2-plan/` để có thể đưa vào Git.
- Không dùng SHA/history để xóa bỏ thay đổi working tree. Không có build/test/benchmark ứng dụng nào được chạy trong lúc soạn bộ tài liệu này.

## Quyết định đã chốt

- Ba service TypeScript: Core, Clinic & Scheduling, Notification.
- Clinic gồm lịch khám/Spa và bệnh án; hotel/tài chính và Identity ở Core.
- RabbitMQ/outbox/inbox, billing reservation, database credentials riêng.
- Identity service thứ tư chưa thuộc phạm vi; tải auth/read surge và shared limiter thuộc phạm vi.
- Một tháng; trước H chỉ bạn + GPT làm tuần tự, sau H mới chia vai trò nhóm. Tuần 4 không mở rộng kiến trúc; ngày bàn giao phải dự báo lại sau P1.
- H có hai bước: nền tảng đủ điều kiện theo checklist, rồi người nhận tái hiện được trên máy riêng. Không ghi thành viên đã tiếp nhận khi chưa có xác nhận thực tế.

## Checkpoint phiên triển khai — mẫu để cập nhật

```text
Ngày giờ/múi giờ:
Người/vai trò/chặng:
Branch/HEAD và trạng thái working tree:
Môi trường thử đã xác minh (không secret):
Hành vi đã hoàn thành:
Files/contracts/migrations đã đổi:
Test command + exit code + PASS/FAIL/SKIP + evidence path:
Invariant còn chưa được kiểm chứng:
Quyết định/ADR mới:
Blocker cụ thể (nếu có):
Bước tiếp theo nhỏ nhất:
Lưu ý không được ghi đè hoặc chạy vào DB đang dùng:
```

## Evidence tối thiểu khi code bắt đầu

Tạo thư mục `phase2-plan/evidence/` khi có dữ liệu thật: baseline.md, api-inventory.csv, test-environment.md, decisions.md, test-results.md, migration-report.md, benchmark-report.md. Những tên này là đầu ra dự kiến, chưa phải file kết quả đã có. Raw logs/dumps chứa dữ liệu lớn hoặc nhạy cảm phải ở thư mục local được loại khỏi Git; report chỉ trỏ artifact an toàn.
